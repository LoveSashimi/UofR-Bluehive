import Foundation

struct Constants {
    struct Storyboard {
        static let homeViewController = "HomeVC"
    }
}
