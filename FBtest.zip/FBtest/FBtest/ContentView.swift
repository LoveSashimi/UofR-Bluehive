//
//  ContentView.swift
//  FBtest
//
//  Created by J D on 2022/10/15.
//

import SwiftUI
import FirebaseCore





struct ContentView: View {
    private let DBF = User_datafetch()
    private let ID=PageID()
    var body: some View {
        NavigationView() {
        VStack(alignment: .center){
            Text("Welcome")
                .font(.title)
                .padding()
            Text("Test1")
                .font(.subheadline)
                .padding(.bottom, 100)
            Text("Mode:"+"Developper")
                .font(.subheadline)
                .padding()
            HStack{
                NavigationLink("Sender", destination: EventView())
                NavigationLink("Reciver", destination: AdminMainView())
            }
        }
        }
            }
   
}




struct AdminListenView: View {
    private let DBF = User_datafetch()
    private let ID=PageID()
    @State private var title = "N/A"
    @State private var title2 = "N/A"
    @State private var H2 = [Hash]()
    @State private var CL = Color.white
    var body: some View {
        var B = DBF.Get_EventData(name:"Event22");
        NavigationView() {
            ZStack{
        CL
                .edgesIgnoringSafeArea([.all])
        VStack {
            Text("Atendee")
                .font(.largeTitle)
                .foregroundColor(Color.red)
            if(H2.count==0){
                Button("Query Event") {
                    H2=DBF.all()
                }
                var U=DBF.ThrData()
            }
            Button("Listen") {
                    CL=Color.blue;
                
            }
            Button("UnListen") {
                    CL=Color.white
            }
            .foregroundColor(Color.white)
            Spacer()
            List{
                ForEach(H2){ Items in
                    VStack{
                        HStack(alignment: .top) {
                           Text(Items.Key)
                            Text(Items.Pass)
                    }
                        HStack(alignment: .top) {
        Button("") {
DBF.DEl_UserData(name: "Test1",Set: Items.Key)
                    }
        .foregroundColor(Color.blue)
                        }
        
                    }
                    }
            }
                
        }
        }
    }
        .navigationBarBackButtonHidden(true)
    }
}




struct AdminMainView: View {
    @State private var inputText = ""
    @State private var input = ""
    @State private var inputcolor = Color.gray
    @State private var H2=[Hash]()
    private let DBF = User_datafetch()
    private let ID=PageID()
    var body: some View {
        NavigationView() {
        VStack(alignment: .center){
            Text("Events Admin page")
                .font(.largeTitle)
            Text("Admin to...?")
            TextField("Input your Event key", text: $inputText,
                                 onEditingChanged: { isBegin in
                                   if isBegin {
                                       inputcolor = Color.black
                                   } else {
                                       inputcolor = Color.gray
                                   }
                       },
                                 onCommit: {
                                   self.input = self.inputText
                                   
            })
            .padding()
            .foregroundColor(inputcolor)
            
            Spacer()
        
            NavigationLink("Log in to "+input, destination: AdminListenView().onAppear{
                DBF.Get_EventData(name:input);
            })
            
        }
            }
   
}
}



struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct EventView: View {
    private let DBF = User_datafetch()
    private let ID=PageID()
    @State private var title = "N/A"
    @State private var title2 = "N/A"
    @State private var H2 = [Hash]()
    var body: some View {
        var B = DBF.Get_UserData(name:"Test1");
        //Text("Hello, world!")
        NavigationView() {
        VStack {
            Text("The Events!")
                .font(.largeTitle)
                .foregroundColor(Color.red)
            NavigationLink("Registar Event", destination: RegistarView())
            if(H2.count==0){
                Button("Query Events") {
                    H2=DBF.all()
                }
                var U=DBF.ThrData()
            }
            Spacer()
            List{
                ForEach(H2){ Items in
                    VStack{
                        HStack(alignment: .top) {
                           Text(Items.Key)
                            Text(Items.Pass)
                    }
                        HStack(alignment: .top) {
        Button("") {
DBF.DEl_UserData(name: "Test1",Set: Items.Key)
                    }
        .foregroundColor(Color.blue)
                            NavigationLink("Delete and Send", destination: EmissionView().onAppear{ID.putID(H:Items.Key)})
                                .foregroundColor(Color.blue)
                        }
        
                    }
                    }
            }
                
        }
    }
    }
}



struct RegistarView: View {
    @Environment(\.dismiss) private var dismiss
    private let DBF = User_datafetch()
    @State private var title = "N/A"
    @State private var title2 = "N/A"
    @State private var inputText = ""
    @State private var input = ""
    @State private var Key = ""
    @State private var Pass = ""
    @State private var Out = ""
    @State private var inputcolor = Color.gray
    var body: some View {
        //Text("Hello, world!")
        NavigationView() {
        VStack (alignment: .center ){
            VStack (alignment: .leading ){
                Text("Registar Events!")
                    .font(.largeTitle)
                    .foregroundColor(Color.blue)
                Spacer()
            TextField("Input your Event key", text: $inputText,
                                 onEditingChanged: { isBegin in
                                   if isBegin {
                                       inputcolor = Color.black
                                   } else {
                                       inputcolor = Color.gray
                                   }
                       },
                                 onCommit: {
                                   self.Key = self.inputText
                                   
                       })
            .font(.title)
            .padding(2)
            TextField("Input your Event Pass", text: $input,
                                 onEditingChanged: { isBegin in
                                   if isBegin {
                                       inputcolor = Color.black
                                   } else {
                                       inputcolor = Color.gray
                                   }
                       },
                                 onCommit: {
                                   self.Pass = self.input
                                   
                       })
            .foregroundColor(inputcolor)
                       .padding(1)
            
            Text("Are You sure registar with following information?")
                Text("Your input Key is -"+Key)
                    .fontWeight(.light)
                Text("Your input pass is -"+Pass)
                    .fontWeight(.light)
            }
            .padding()
            .padding()

            
            Button("Registar") {
                if(Pass != "" && Key != ""){
                    DBF.Send_UserData(name: "Test1",Set:Key,Value:Pass)
                    inputText = ""
                    Key = ""
                    Pass = ""
                    input = ""
                    Out="Registration Sccess!"
                }
                else{
                    Out="Please input something for Key and Pass"
                }
            }
        Text(Out)
            .fontWeight(.medium)
            .foregroundColor(.yellow)
            Button("Dismiss") {
            //DBF.DEl_UserData(name: "Test1",Set: ID.ID)
                dismiss()
            }
            .foregroundColor(Color.red)
           
        }
        }
        .navigationBarBackButtonHidden(true)
    }
}

struct EmissionView: View {
    @Environment(\.dismiss) private var dismiss
    private let DBF = User_datafetch()
    private let ID=PageID()
    @State private var BG = Color.white
    @State private var title = "N/A"
    var body: some View {
        NavigationView() {
        ZStack{
           BG
            .edgesIgnoringSafeArea([.all])
        VStack {
            Text("Bluetooth Emission")
                .font(.largeTitle)
                .foregroundColor(Color.red)
            Spacer()
            Text("Signal Passed!")
                .font(.largeTitle)
                .foregroundColor(Color.white)
            Text("Emitting - "+ID.ID)
        Image("shopping")
            .resizable()
         .frame(width: 330, height: 330, alignment: .center)
         .aspectRatio(contentMode: .fit)
            Button("Get Signal") {
            DBF.DEl_UserData(name: "Test1",Set: ID.ID)
                BG=Color.green
                ID.ID="Nil"
            }
            .foregroundColor(Color.gray)
            Button("Dismiss") {
            //DBF.DEl_UserData(name: "Test1",Set: ID.ID)
                dismiss()
            }
            .foregroundColor(Color.red)
        }
        }
            }
        .navigationBarBackButtonHidden(true)
    }
        
   
}




