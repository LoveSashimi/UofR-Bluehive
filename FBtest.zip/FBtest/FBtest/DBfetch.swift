//
//  DBfetch.swift
//  FBtest
//
//  Created by J D on 2022/10/15.
//

import Foundation
import Firebase
import UIKit

class User_datafetch{
    func Send_UserData(name:String, Set:String,Value:String ){
       let db=Database.database().reference()
        db.child("Persons").child("Users").child(name).child(Set).setValue(Value)
    }
    func DEl_UserData(name:String, Set:String){
       let db=Database.database().reference()
        db.child("Persons").child("Users").child(name).child(Set).removeValue()
    }
    var postdata=[String]()
    var postdataV=[String]()
    var Eventname="N/A"
    func ThrData(){
        postdata=[String]()
        postdataV=[String]()
    }
    
    func Get_EventData(name:String) {
        Eventname=name
        print("Event")
       let db=Database.database().reference()
       db.child("Events").child("Identifer").child(name).observeSingleEvent(of: .value, with: {
     (snapshot)->Void in
            let Cur = snapshot.children
            Cur.forEach { i in
                let Y=i  as?  DataSnapshot
                let X=Y!.key
                let Z=Y!.value as? String
                self.postdata.append(X)
                self.postdataV.append(Z!)
                print(i)
                print(X)
            }
          })
            Thread.sleep(forTimeInterval: 1.0)
            print("PRINTEDDD")
            print(postdata);
        return;
    }
    
    
    func Get_UserData(name:String) {
       let db=Database.database().reference()
       db.child("Persons").child("Users").child(name).observeSingleEvent(of: .value, with: {
     (snapshot)->Void in
            let Cur = snapshot.children
            Cur.forEach { i in
                let Y=i  as?  DataSnapshot
                let X=Y!.key
                let Z=Y!.value as? String
                self.postdata.append(X)
                self.postdataV.append(Z!)
                print(i)
                print(X)
            }
          })
            Thread.sleep(forTimeInterval: 1.0)
            print("PRINTEDDD")
            print(postdata);
        return;
    }
    func all()->[Hash]{
        var Res=[Hash]()
        if(postdata.count != 0 && postdata.count == postdataV.count){
            for ct in 0...postdata.count-1{
                Res.append(Hash(Key:postdata[ct],Pass:postdataV[ct]));
            }
        }
        
        return Res;
    }
    }

struct Hash:Identifiable {
    let id=UUID()
    let Key:String
    let Pass:String
}

class PageID {
   var ID="N/A"
    func putID(H:String){
        ID=H;
    }
}
